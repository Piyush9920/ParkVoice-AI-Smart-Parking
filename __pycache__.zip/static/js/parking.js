/**
 * ParkVoice AI - Visual Parking Map & A* Navigation Route Renderer
 * ================================================================
 * Features:
 * - 4x3 Grid (P01–P12) with dedicated Entrance Gate (4, 1)
 * - Real-time slot status rendering (AVAILABLE, OCCUPIED, RESERVED)
 * - Animated SVG A* path polyline from Entrance to destination
 * - 3-second live telemetry polling
 * - Active booking elapsed timer
 * - Interactive slot inspection and manual path tracing
 */

let cachedSlots = [];
let currentActiveBooking = null;
let bookingTimerInterval = null;
let currentDrawnPath = [];
let currentRecommendedSlot = null;
let selectedModalSlot = null;

document.addEventListener("DOMContentLoaded", () => {
  reloadParkingMap();
  checkActiveBooking();

  // Polling every 3 seconds for live simulation and multi-client updates
  setInterval(() => {
    reloadParkingMap(true);
  }, 3000);

  // Window resize re-draws active route SVG points
  window.addEventListener("resize", () => {
    if (currentDrawnPath && currentDrawnPath.length > 0) {
      renderSvgRoute(currentDrawnPath);
    }
  });

  // Modal Action Buttons
  const btnModalRoute = document.getElementById("modalBtnRoute");
  if (btnModalRoute) {
    btnModalRoute.addEventListener("click", () => {
      if (selectedModalSlot) {
        closeSlotModal();
        traceRouteToSlot(selectedModalSlot.slot_number);
      }
    });
  }

  const btnModalBook = document.getElementById("modalBtnBook");
  if (btnModalBook) {
    btnModalBook.addEventListener("click", () => {
      if (selectedModalSlot) {
        closeSlotModal();
        executeBooking(selectedModalSlot.slot_number, selectedModalSlot.id);
      }
    });
  }

  // Active Booking Action Buttons
  const btnCancel = document.getElementById("btnCancelActiveBooking");
  if (btnCancel) {
    btnCancel.addEventListener("click", () => {
      if (confirm("Are you sure you want to cancel your active parking reservation?")) {
        simulateVoiceCommand("Cancel my booking");
      }
    });
  }

  const btnRelease = document.getElementById("btnReleaseActiveBooking");
  if (btnRelease) {
    btnRelease.addEventListener("click", () => {
      if (confirm("Complete parking session and depart?")) {
        simulateVoiceCommand("Release parking");
      }
    });
  }

  // Recommendation Card Confirm Button
  const btnBookRec = document.getElementById("btnBookRecommended");
  if (btnBookRec) {
    btnBookRec.addEventListener("click", () => {
      if (currentRecommendedSlot) {
        executeBooking(currentRecommendedSlot.slot_number, currentRecommendedSlot.id);
      }
    });
  }
});

// Fetch and render the 4x3 parking grid
async function reloadParkingMap(isBackgroundPoll = false) {
  try {
    const res = await fetch("/api/parking/slots");
    const data = await res.json();
    if (!data.success) return;

    cachedSlots = data.slots;
    updateStatsBar(data.slots);
    render4x3Grid(data.slots);

    // If there is an active booking, ensure its route is shown
    if (!isBackgroundPoll) {
      checkActiveBooking();
    }
  } catch (err) {
    console.error("Failed to load parking slots:", err);
  }
}

// Update Top Stats Bar
function updateStatsBar(slots) {
  const avail = slots.filter(s => s.status === "AVAILABLE").length;
  const occ = slots.filter(s => s.status === "OCCUPIED").length;
  const res = slots.filter(s => s.status === "RESERVED").length;

  const elAvail = document.getElementById("statAvailableCount");
  const elOcc = document.getElementById("statOccupiedCount");
  const elRes = document.getElementById("statReservedCount");

  if (elAvail) elAvail.innerText = avail;
  if (elOcc) elOcc.innerText = occ;
  if (elRes) elRes.innerText = res;
}

// Render 4x3 Grid
function render4x3Grid(slots) {
  const gridContainer = document.getElementById("parkingGrid");
  if (!gridContainer) return;

  gridContainer.innerHTML = slots.map(slot => {
    const isRecommended = currentRecommendedSlot && currentRecommendedSlot.slot_number === slot.slot_number;
    let badgeText = slot.status;
    let badgeClass = "badge-available";

    if (slot.status === "OCCUPIED") {
      badgeClass = "badge-occupied";
    } else if (slot.status === "RESERVED") {
      badgeClass = "badge-reserved";
    }

    const evIndicator = slot.has_ev_charger
      ? `<span class="ev-tag">⚡ EV FAST</span>`
      : ``;

    return `
      <div id="slot-card-${slot.slot_number}" 
           class="parking-slot-card status-${slot.status} ${isRecommended ? 'is-recommended' : ''}"
           data-slot="${slot.slot_number}"
           data-row="${slot.row_index}"
           data-col="${slot.col_index}"
           onclick="openSlotModal('${slot.slot_number}')">
        
        <div class="slot-top">
          <span class="slot-id">${slot.slot_number}</span>
          <span class="slot-badge ${badgeClass}">${badgeText}</span>
        </div>

        <div class="slot-center">
          ${evIndicator}
          <span>${slot.slot_type}</span>
        </div>

        <div class="slot-bottom">
          <span>$${slot.price_per_hour.toFixed(2)}/hr</span>
          <span>(${slot.row_index}, ${slot.col_index})</span>
        </div>
      </div>
    `;
  }).join("");

  // Re-draw SVG route points if active
  if (currentDrawnPath && currentDrawnPath.length > 0) {
    requestAnimationFrame(() => renderSvgRoute(currentDrawnPath));
  }
}

// Highlight Recommended Slot & Trace A* Route
function highlightRecommendedSlot(slot, path, distance) {
  currentRecommendedSlot = slot;
  currentDrawnPath = path;

  // Show recommendation card in right column
  const card = document.getElementById("recommendationCard");
  if (card) {
    card.style.display = "block";
    document.getElementById("recSlotNumber").innerText = slot.slot_number;
    document.getElementById("recPriceTag").innerText = `$${slot.price_per_hour.toFixed(2)}/hr`;
    document.getElementById("recDistPill").innerText = `📍 ${distance} steps from entrance`;
    document.getElementById("recTypePill").innerText = `${slot.slot_type}${slot.has_ev_charger ? ' • EV Fast Charger' : ''}`;
    document.getElementById("recReasonText").innerText = `Optimal navigable slot selected using A* Manhattan distance heuristic.`;
    document.getElementById("recTimeStr").innerText = `~${Math.max(15, distance * 12)} sec drive`;
  }

  // Re-render grid to apply pulse effect
  render4x3Grid(cachedSlots);
  renderSvgRoute(path);

  const statusText = document.getElementById("routeStatusText");
  if (statusText) {
    statusText.innerText = `A* Path to ${slot.slot_number}: ${distance} steps`;
  }
}

// Trace A* Route to a specific slot via API
async function traceRouteToSlot(slotNumber) {
  try {
    const res = await fetch("/api/parking/path", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slot_number: slotNumber })
    });

    const data = await res.json();
    if (data.success && data.path.length > 0) {
      currentDrawnPath = data.path;
      renderSvgRoute(data.path);

      const statusText = document.getElementById("routeStatusText");
      if (statusText) {
        statusText.innerText = `A* Route to ${slotNumber}: ${data.distance} steps`;
      }
      showToast(`A* path calculated to ${slotNumber} (${data.distance} steps)`, "info");
    } else {
      showToast(`No clear path found to slot ${slotNumber}`, "warning");
    }
  } catch (err) {
    console.error("Error tracing route:", err);
  }
}

// Render SVG Polyline across Grid Coordinates
function renderSvgRoute(path) {
  const stage = document.getElementById("gridStage");
  const polyline = document.getElementById("routePolyline");
  const entranceEl = document.getElementById("entranceGate");

  if (!stage || !polyline || !entranceEl || !path || path.length === 0) return;

  const stageRect = stage.getBoundingClientRect();
  const points = [];

  // Remove existing route markers
  document.querySelectorAll(".parking-slot-card").forEach(el => el.classList.remove("on-route"));

  path.forEach((coord, index) => {
    const [r, c] = coord;

    if (r === 4 && c === 1) {
      // Entrance Gate center
      const gateRect = entranceEl.getBoundingClientRect();
      const x = (gateRect.left + gateRect.width / 2) - stageRect.left;
      const y = (gateRect.top + gateRect.height / 2) - stageRect.top;
      points.push(`${x},${y}`);
    } else {
      // Match with slot card if in 4x3 range
      const slot = cachedSlots.find(s => s.row_index === r && s.col_index === c);
      if (slot) {
        const slotEl = document.getElementById(`slot-card-${slot.slot_number}`);
        if (slotEl) {
          slotEl.classList.add("on-route");
          const rect = slotEl.getBoundingClientRect();
          const x = (rect.left + rect.width / 2) - stageRect.left;
          const y = (rect.top + rect.height / 2) - stageRect.top;
          points.push(`${x},${y}`);
        }
      } else {
        // Aisle or perimeter waypoint
        // Estimate coordinates relative to grid cells
        const colWidth = stageRect.width / 3;
        const rowHeight = (stageRect.height - 80) / 4;
        const x = Math.max(20, Math.min(stageRect.width - 20, (c + 0.5) * colWidth));
        const y = Math.max(20, (r + 0.5) * rowHeight);
        points.push(`${x},${y}`);
      }
    }
  });

  polyline.setAttribute("points", points.join(" "));
}

// Check if logged-in user has an active booking
async function checkActiveBooking() {
  try {
    const res = await fetch("/api/bookings/active");
    const data = await res.json();
    const card = document.getElementById("activeBookingCard");

    if (data.success && data.active_booking) {
      currentActiveBooking = data.active_booking;
      if (card) card.style.display = "block";

      document.getElementById("activeSlotTag").innerText = data.active_booking.slot_number;
      document.getElementById("activeBookingCode").innerText = data.active_booking.booking_code;
      document.getElementById("activeVehicleInfo").innerText = 
        `Vehicle: ${data.active_booking.plate_number} (${data.active_booking.model})`;

      // Start live elapsed timer
      startBookingTimer(data.active_booking.start_time);

      // Auto-render route to user's reserved slot
      if (data.active_booking.path && data.active_booking.path.length > 0) {
        currentDrawnPath = data.active_booking.path;
        renderSvgRoute(data.active_booking.path);
      }
    } else {
      currentActiveBooking = null;
      if (card) card.style.display = "none";
      if (bookingTimerInterval) clearInterval(bookingTimerInterval);
    }
  } catch (err) {
    console.error("Error checking active booking:", err);
  }
}

// Live Elapsed Timer
function startBookingTimer(startTimeIso) {
  if (bookingTimerInterval) clearInterval(bookingTimerInterval);
  const startMs = new Date(startTimeIso).getTime();

  const update = () => {
    const nowMs = Date.now();
    const diffSec = Math.max(0, Math.floor((nowMs - startMs) / 1000));
    const hrs = String(Math.floor(diffSec / 3600)).padStart(2, "0");
    const mins = String(Math.floor((diffSec % 3600) / 60)).padStart(2, "0");
    const secs = String(diffSec % 60).padStart(2, "0");

    const timerEl = document.getElementById("bookingElapsed");
    if (timerEl) timerEl.innerText = `${hrs}:${mins}:${secs}`;
  };

  update();
  bookingTimerInterval = setInterval(update, 1000);
}

// Slot Inspection Modal
function openSlotModal(slotNumber) {
  const slot = cachedSlots.find(s => s.slot_number === slotNumber);
  if (!slot) return;

  selectedModalSlot = slot;
  document.getElementById("modalSlotTitle").innerText = `Slot ${slot.slot_number}`;
  document.getElementById("modalSlotStatus").innerText = slot.status;
  document.getElementById("modalSlotStatus").style.color = 
    slot.status === "AVAILABLE" ? "var(--status-available)" :
    slot.status === "OCCUPIED" ? "var(--status-occupied)" : "var(--status-reserved)";
  
  document.getElementById("modalSlotPrice").innerText = `$${slot.price_per_hour.toFixed(2)}/hr`;
  document.getElementById("modalSlotType").innerText = slot.slot_type;
  document.getElementById("modalSlotEV").innerText = slot.has_ev_charger ? "⚡ Equipped (Fast Charge)" : "Standard";

  const occupantEl = document.getElementById("modalSlotOccupant");
  if (slot.status !== "AVAILABLE" && slot.booked_by_name) {
    occupantEl.style.display = "block";
    document.getElementById("modalOccupantName").innerText = `${slot.booked_by_name} (${slot.plate_number || 'Vehicle'})`;
  } else {
    occupantEl.style.display = "none";
  }

  // Toggle book button state
  const bookBtn = document.getElementById("modalBtnBook");
  if (bookBtn) {
    if (slot.status === "AVAILABLE") {
      bookBtn.style.display = "inline-flex";
      bookBtn.disabled = false;
    } else {
      bookBtn.style.display = "none";
    }
  }

  document.getElementById("slotModal").style.display = "flex";
}

function closeSlotModal() {
  document.getElementById("slotModal").style.display = "none";
  selectedModalSlot = null;
}
